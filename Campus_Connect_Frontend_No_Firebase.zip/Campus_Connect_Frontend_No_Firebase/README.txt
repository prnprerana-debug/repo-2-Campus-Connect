CAMPUS CONNECT — FRONTEND-ONLY VERSION (NO FIREBASE)
===================================================

This ZIP contains the website frontend only. Firebase files and Firebase scripts have been removed.

FILES
- index.html: Home page
- information.html: Information page with sample information cards
- ask-seniors.html: Question-and-answer demo
- projects.html: Project showcase
- login.html and register.html: Frontend demo account forms
- seniors.html: Senior profiles page
- style.css: Website styling
- app.js: Browser-side interactions

HOW TO RUN
1. Extract this ZIP.
2. Open the extracted folder in VS Code.
3. Open index.html with the Live Server extension (or open index.html in a browser).

IMPORTANT LIMITATION
This is a frontend demonstration, not a connected multi-user application. Demo accounts, questions, answers and project-interest submissions are stored in the browser's localStorage. They are visible only in the same browser on the same device. They will NOT sync to teammates' devices and are not secure authentication.

BACKEND TEAMMATE
Your backend teammate can later connect these frontend pages/forms to the backend/API. You do not need Firebase to work on or present the frontend. Coordinate with the backend teammate about API endpoints and the data format before integration.

GITHUB
You can upload these files to GitHub and publish the static frontend using GitHub Pages. GitHub Pages hosts the frontend only; it does not provide a database or backend server.
